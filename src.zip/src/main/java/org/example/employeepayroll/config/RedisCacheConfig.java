//package org.example.employeepayroll.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.redis.cache.RedisCacheConfiguration;
//import org.springframework.data.redis.cache.RedisCacheManager;
//import org.springframework.data.redis.connection.RedisConnectionFactory;
//import org.springframework.data.redis.serializer.GenericJacksonJsonRedisSerializer;
//import org.springframework.data.redis.serializer.RedisSerializationContext;
//
//import java.time.Duration;
//
//@Configuration
//public class RedisCacheConfig {
//
//    @Bean
//    public RedisCacheManager cacheManager(RedisConnectionFactory factory) {
//
//        GenericJacksonJsonRedisSerializer serializer = GenericJacksonJsonRedisSerializer
//                .builder()
//                .enableUnsafeDefaultTyping()
//                .build();
//
//        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
//                .serializeValuesWith(
//                        RedisSerializationContext.SerializationPair.fromSerializer(serializer)
//                )
//                .entryTtl(Duration.ofMinutes(10));
//
//        return RedisCacheManager.builder(factory)
//                .cacheDefaults(config)
//                .build();
//    }
//}
