package org.example.employeepayroll.entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

//@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LeaveRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private String leaveType;

    private LocalDate fromDate;

    private LocalDate toDate;

    private Double daysCount;

    private String status;

    private String monthYear;
}
