package org.example.employeepayroll.entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

//@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaySlip {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payroll_run_id")
    private PayrollRun payrollRun;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private Double grossSalary;

    private Double totalDeductions;

    private Double netSalary;

    private Double daysPresent;

    private Double daysAbsent;

    private Double leaveDeduction;

    private Double overtimePay;

    private String status;

    private LocalDateTime generatedAt;
}
