package org.example.employeepayroll.repositories;

import org.example.employeepayroll.entities.Role;
import org.example.employeepayroll.entities.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<Users, Long> {
    Optional<Users> findByUsername(String username);

    Collection<Users> findByRole(Role role);
}
